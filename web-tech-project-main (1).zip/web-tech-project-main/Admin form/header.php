<header>
            <div class="main">
                <div class="logo">
                    <img src="jersey.png">
                </div>
    
                <ul id="nav">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a href="registration.php">Registration</a></li>
                   
                </ul>
           
        
             <h1> jerseyBD(Admin) </h1>
            
                
            </div>

            </header>


          