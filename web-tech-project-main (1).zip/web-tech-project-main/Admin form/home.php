<!DOCTYPE html>
<html>
    <head>
        
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
    	<?php include 'header.php' ?>

          <h1>WELCOME</h1>

    <img src="2.jpg" height="900px" width="1670px">


            <?php include 'footer.php' ?>
            
          </body>
</html>
