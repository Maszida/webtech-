<div id="sidebar">
             <ul >
                   
                    <li ><a href="viewprofile.php"><span style="color: blue">View Profile</span></a></li>
                    <li><a href="edit.php"><span style="color: blue">Edit Profile</span></a></li>
                    <li><a href="uploadprofile.php"><span style="color: blue">Upload Profile Picture</span></a></li>
                    <li><a href="changeprofilepic.php"><span style="color: blue">Change Profile Picture</span></a></li>
                    <li><a href="changepassword.php"><span style="color: blue">Change Password</span></a></li>
                    
            </ul>
        </div>
