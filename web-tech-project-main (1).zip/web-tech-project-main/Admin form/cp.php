<!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin </title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Delete / Edit Post</legend>
    <p> Delete/Edit Post</p>
    <table>
    <tr>
      <th>Post Number</th>
      <th>Post</th>
      <th colspan="3" align="center">Operation</th>
     
    </tr>
    <tr>
      <td>1</td>
       <td><p> Product was Good</td>
       <td> <a href=""><span style='color: blue'>Edit</a></td>
        <td> <a href=""><span style='color: blue'>Delete</a></td>
        


     </tr>
     </tr>
     </table>
            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>