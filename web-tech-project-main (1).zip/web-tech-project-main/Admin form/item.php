<!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin Info</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Item Info</legend>
    <p>Item Table </p>
    <table>
    <tr>
      <th>Item Name</th>
      <th>Stock</th>
      <th colspan="3" align="center">Operation</th>
     
    </tr>
    <tr>
      <td>International Jersey</td>
       <td>100</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>
     </tr>

     <tr>
      <td>National Jersey</td>
       <td>80</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
     </tr>

      <tr>
      <td>Club Jersey</td>
       <td>90</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

     </tr>

      <tr>
      <td>Shorts</td>
       <td>50</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


           <tr>
      <td>Cricket Bat</td>
       <td>50</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


           <tr>
      <td>Football</td>
       <td>50</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

           <tr>
      <td>Badminton Bat</td>
       <td>40</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

           <tr>
      <td>Boots</td>
       <td>50</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

     </tr> 
   </table>



      

      </table>
            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>
          

