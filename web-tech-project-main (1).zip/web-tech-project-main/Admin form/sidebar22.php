<div id="sidebar">
             <ul >
                   
                    <li ><a href="me.php"><span style="color: blue"> Manager & Employee(Add/update/Remove)</span></a></li>
                    <li><a href="item.php"><span style="color: blue">Item(Add/update)</span></a></li>
                    <li><a href="maintainstock.php"><span style="color: blue">Maintainance stock</span></a></li>
                    <li><a href="managerpromotions.php"><span style="color: blue">Manager promotions</span></a></li>
                    <li><a href="salaryandovertime.php"><span style="color: blue">Salary and overtime generation</span></a></li>
                    <li><a href="cp.php"><span style="color: blue">Delete/Edit Post</span></a></li>
                    
                    
            </ul>
        </div>
