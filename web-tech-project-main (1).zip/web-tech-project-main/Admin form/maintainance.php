
<!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin Info</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Maintainance Stock</legend>
    <p>product stock Table </p>
    <table>
    <tr>
      <th>Catagory Name</th>
      <th>Item name</th>
      <th>Address</th>
      <th>Phone Number</th>
      <th colspan="3" align="center">Operation</th>
     
    </tr>
    <tr>
      <td>sinthia</td>
       <td>sinthia12@gmail.com</td>
       <td>khilgaon</td>
       <td>01713145600</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>
     </tr>

     <tr>
      <td>jeelan</td>
       <td>jeelan45@gmail.com</td>
       <td>Mirpur</td>
       <td>01934517452</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
     </tr>

      <tr>
      <td>Mim</td>
       <td>mim56@gmail.com</td>
       <td>Rampura</td>
       <td>01653471956</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

     </tr>

      <tr>
      <td>Moniul</td>
       <td>moniul11@gmail.com</td>
       <td>Dhanmondi</td>
       <td>01756890361</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

     </tr> 
   </table>

   




      <p>Manager Table</p>
      <table>
     <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Address</th>
      <th>Phone Number</th>
      <th colspan="3" align="center">Operation</th>
    </tr>
    <tr>
      <td>piya</td>
       <td>piya3@gmail.com</td>
       <td>khulna</td>
       <td>01713145600</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>

     </tr>

     <tr>
      <td>Rafi</td>
       <td>rafi83@gmail.com</td>
       <td>Banasree</td>
       <td>01934517452</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
     </tr>

      <tr>
      <td>Shafin</td>
       <td>shafin56@gmail.com</td>
       <td>Bailyroad</td>
       <td>01653471956</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
     </tr>

      <tr>
      <td>Azad</td>
       <td>azad11@gmail.com</td>
       <td>Tangail</td>
       <td>01756890361</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
     </tr>

      <tr>
          
          








              
                 

         
             </table>
            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>
 


