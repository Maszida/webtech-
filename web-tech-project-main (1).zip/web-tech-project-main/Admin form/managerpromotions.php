<!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin </title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Manager Salary Implemention</legend>
    <p>Manager Salary Implemention Table </p>
    <table>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Previous Salary</th>
      <th>Updated Salary</th>
     
     
    </tr>
    <tr>
      <td>sinthia</td>
       <td>sinthia12@gmail.com</td>
       <td>5000</td>
       <td>6000</td>
       

     </tr>
     </tr>

     <tr>
      <td>jeelan</td>
       <td>jeelan45@gmail.com</td>
       <td>5000</td>
       <td>6000</td>
       
       
     </tr>

      <tr>
      <td>Mim</td>
       <td>mim56@gmail.com</td>
       <td>5000</td>
       <td>6000</td>
       
     </tr>

      <tr>
      <td>Moniul</td>
       <td>moniul11@gmail.com</td>
       <td>5000</td>
       <td>6000</td>
       
     </tr> 
   </table>

            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>

   
