<header>
            <div class="main">
                <div class="logo">
                    <img src="jersey.png">
                </div>
    
                <ul id="nav">
                    <li><a href="#">Login as Customer</a></li>
                    <li><a href="product.php">Product</a></li>
                 

                    
                </ul>

               

                
        
             <h1> jerseyBD </h1>
            
                
            </div>

            </header>