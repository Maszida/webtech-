
<!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin Info</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Maintainance Stock</legend>
    <p>product stock Table </p>
    <table>
    <tr>
      <th>Catagory Name</th>
      <th>Item name</th>
      <th>Size</th>
      <th>Stock</th>
      <th colspan="3" align="center">Operation</th>
     
    </tr>
    <tr>
      <td>International Jesey</td>
      <td>Item Name
      
       <select>
                  
                  <option>Belgium</option>
                  <option>Brazil</option>
                  <option>Argentina</option>
                  <option>Spain</option>
                  <option>Germany</option>
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>MEDIUM</option>
                  <option>LARGE</option>
                  <option>XL</option>
                  <option>2XL</option>
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Belgium(200)</option>
                  <option>Brazil(300)</option>
                  <option>Argentina(400)</option>
                  <option>Spain(400)</option>
                  <option>Germany(500)</option>
                    <br><br>
                  </select>
                </td>



       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>



          


     </tr>

     <tr>
      <td>Club Jesey</td>
      <td>Item Name
      
       <select>
                  
                  <option>Barcelona</option>
                  <option>Manchester United</option>
                  <option>Real Madrid</option>
                  <option>Arsenal</option>
                  
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>MEDIUM</option>
                  <option>LARGE</option>
                  <option>XL</option>
                  <option>2XL</option>
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Barcelona(200)</option>
                  <option>Manchester(300)</option>
                  <option>Real Madrid(400)</option>
                  <option>Arsenal(400)</option>
                  
                    <br><br>
                  </select>
                </td>



       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>

     <tr>
      <td>Shorts</td>
      <td>Item Name
      
       <select>
                  
                  <option>Blue</option>
                  <option>Black</option>
                  <option>White</option>
                  <option>Red</option>
                  <option>Navy Blue</option>
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>MEDIUM</option>
                  <option>LARGE</option>
                  <option>XL</option>
                  <option>2XL</option>
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Blue Shorts(200)</option>
                  <option>Black(300)</option>
                  <option>White(400)</option>
                  <option>Red(400)</option>
                  <option>Navy Blue(500)</option>
                    <br><br>
                  </select>
                </td>

                <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>



              </tr>

              <tr>
      <td>Cricket Bat</td>
      <td>Item Name
      
       <select>
                  
                  <option>Mrfnike</option>
                  <option>Adidas</option>
                  <option>GM</option>
                  <option>Kookaburra</option>
                  
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>Normal</option>
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Small(200)</option>
                  <option>Normal(300)</option>
                  
                    <br><br>
                  </select>
                </td>
             




       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>
        

             </tr>


             <tr>
      <td>Football Name</td>
      <td>Item Name
      
       <select>
                  
                  <option>Addidas Jabulani</option>
                  <option>Telstar Mechta</option>
                  <option>Brazuca</option>
                 
                  
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>Normal</option>
                  
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Addidas Jabulani(200)</option>
                  <option>Telstar Mechta(300)</option>
                  <option>Brazuca(400)</option>
                  
                    <br><br>
                  </select>
                </td>



       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>


      <tr>
      <td>Badminton Bat Name</td>
      <td>Item Name
      
       <select>
                  
                  <option>Li-Ning</option>
                  <option>Yonex Arc Saber</option>
                  <option>Yonex Nanoray 9i</option>
                 
                  
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>SMALL</option>
                  <option>Normal</option>
                  
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Li-Ning(200)</option>
                  <option>Yonex Arc Saber(300)</option>
                  <option>Yonex Nanoray(400)</option>
                  
                    <br><br>
                  </select>
                </td>



       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>

      <tr>
      <td>Boots Name</td>
      <td>Item Name
      
       <select>
                  
                  <option>Greson</option>
                  <option>Timberland</option>
                  <option>Belstaff</option>
                 
                  
                    <br><br>
                  </select>
                </td>

       <td>Size

         <select>
                  
                  <option>6 inches</option>
                  <option>6.5 inches</option>
                  <option>7 inches</option>
                  <option>7.5 inches</option>
                  <option>8 inches</option>
                  <option>8.5 inches</option>
                  
                  

                  
                    <br><br>
                  </select>
                </td>

       <td>stock

        <select>
                  
                  <option>Greson(200)</option>
                  <option>Timberland(300)</option>
                  <option>Belstaff(400)</option>
                  
                    <br><br>
                  </select>
                </td>



       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         <td> <a href=""><span style='color: blue'>Remove</a></td>


     </tr>
         
         



      




      



     






              
                 

         
             </table>
            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>
 


