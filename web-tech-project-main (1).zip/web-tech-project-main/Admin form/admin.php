<?php


session_start();  
?>

<!DOCTYPE html>
<html>
    <head>
        
        <title>Admin</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em">Admin</legend>

            <br>

         <?php include 'sidebar22.php' ?>

            <?php include 'footer.php' ?>
            
          </body>
</html>
