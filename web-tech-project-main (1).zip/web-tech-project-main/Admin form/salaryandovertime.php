 <!DOCTYPE html>
<html>
    <head>
      <style>table,th,td{border:1px solid black;}
    </style>
        
        <title>Admin </title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
      <?php include 'header14.php' ?>
      <fieldset>
    <legend align="center" style="font-size: 2.0em"> Salary and Overtime Generation</legend>
    <p>  Employee Salary and Overtime Implementation </p>
    <table>
    <tr>
      <th> Employee Name</th>
      <th> Employee Email</th>
      <th> Salary</th>
      <th>Overtime(per week)</th>
      <th>Overtime Salary</th>
      <th colspan="3" align="center">Operation</th>
     
    </tr>
    <tr>
      <td>sinthia</td>
       <td>sinthia12@gmail.com</td>
       <td>5000</td>
       <td>1 hour</td>
        <td>+100</td>

       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         


     </tr>
     </tr>

     <tr>
      <td>jeelan</td>
       <td>jeelan45@gmail.com</td>
       <td>5000</td>
       <td>2 hour</td>
        <td>+200</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
       
     </tr>

      <tr>
      <td>Mim</td>
       <td>mim56@gmail.com</td>
       <td>5000</td>
       <td>4hour</td>
        <td>+400</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Update</a></td>
         
     </tr>

      <tr>
      <td>Moniul</td>
       <td>moniul11@gmail.com</td>
       <td>5000</td>
       <td>5 hour</td>
        <td>+500</td>
       <td> <a href=""><span style='color: blue'>Add</a></td>
        <td> <a href=""><span style='color: blue'>Udate</a></td>

     </tr> 


 </table>
            <?php include 'footer.php' ?>
            </fieldset>
           

          </body>
          
</html>