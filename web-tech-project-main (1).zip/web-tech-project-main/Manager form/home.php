<!DOCTYPE html>
<html>
    <head>
        
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
    	<?php include 'header.php' ?>

          <h1>WELCOME</h1>

            <?php include 'footer.php' ?>
            
          </body>
</html>
