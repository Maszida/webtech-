<header>
            <div class="main">
                <div class="logo">
                    <img src="jersey.png">
                </div>
    
                <ul id="nav">
                    <li><a href="#">Login as Admin</a></li>
                    <li><a href="admin.php">Admin</a></li>
                    <li><a href="login.php">logout</a></li>

                    
                </ul>

               

                
        
             <h1> jerseyBD(Admin) </h1>
            
                
            </div>

            </header>