<header>
            <div class="main">
                <div class="logo">
                    <img src="logo.png">
                </div>
    
                <ul id="nav">
                    <li class="active"><a href="home.php">Home</a></li>
                    <li><a href="product.php">Product</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a href="registration.php">Registration</a></li>
                    <li><a href="about.php">About</a></li>
                     <li><a href="contact.php">Contact</a></li>
                 </ul>

                  </header>